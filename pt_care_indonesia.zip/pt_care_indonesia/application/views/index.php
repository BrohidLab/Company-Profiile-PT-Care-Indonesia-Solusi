<!DOCTYPE html>
<html lang="en">
  <head>
    <title>PT. Care Indonesia Solusi </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="author" content="Free-Template.co" />

    <!-- 
    //////////////////////////////////////////////////////

    FREE TEMPLATE 
    DESIGNED & DEVELOPED by free-template.co
      
    Website:    https://free-template.co
    Facebook:   https://www.facebook.com/FreeDashTemplate.co
    Twitter:    https://twitter.com/Free_Templateco

    //////////////////////////////////////////////////////
    -->

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,700,900|Display+Playfair:200,300,400,700"> 
    <link rel="stylesheet" href="<?php echo base_url();?>/assets/fonts/icomoon/style.css">

    <link rel="stylesheet" href="<?php echo base_url();?>/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>/assets/css/magnific-popup.css">
    <link rel="stylesheet" href="<?php echo base_url();?>/assets/css/jquery-ui.css">
    <link rel="stylesheet" href="<?php echo base_url();?>/assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>/assets/css/owl.theme.default.min.css">

    <link rel="stylesheet" href="<?php echo base_url();?>/assets/css/bootstrap-datepicker.css">

    <!-- <link rel="stylesheet" href="<?php echo base_url();?>/assets/fonts/flaticon/font/flaticon.css">
     --><link rel="stylesheet" href="<?php echo base_url();?>/assets/fonts/flaticon_service/font/flaticon.css">



    <link rel="stylesheet" href="<?php echo base_url();?>/assets/css/aos.css">

    <link rel="stylesheet" href="<?php echo base_url();?>/assets/css/style.css">
    
  </head>
  <body data-spy="scroll" data-target=".site-navbar-target" data-offset="200">
  
  <!-- <div class="site-wrap"> -->

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>
    
    <header class="site-navbar py-3 js-site-navbar site-navbar-target" role="banner" id="site-navbar">

      <div class="container">
        <div class="row align-items-center">
          
          <div class="col-11 col-xl-2 site-logo">
            <h1 class="mb-0"><a href="index.html" class="text-white h2 mb-0"></a></h1>
          </div>
          <div class="col-12 col-md-10 d-none d-xl-block">
            <nav class="site-navigation position-relative text-right" role="navigation">

              <ul class="site-menu js-clone-nav mx-auto d-none d-lg-block">
                <li><a href="#section-home" class="nav-link">Home</a></li>
                <li>
                  <a href="#section-about" class="nav-link">About Us</a>
                </li>
                <li><a href="#section-our-team" class="nav-link">Our Partner</a></li>
                <li><a href="#section-services" class="nav-link">Services</a></li>
                <li><a href="#section-contact" class="nav-link">Contact</a></li>
              </ul>
            </nav>
          </div>


          <div class="d-inline-block d-xl-none ml-md-0 mr-auto py-3" style="position: relative; top: 3px;"><a href="#" class="site-menu-toggle js-menu-toggle"><span class="icon-menu h3"></span></a></div>

          </div>

        </div>
      </div>
      
    </header>

  

    <div class="site-blocks-cover overlay" style="background-image: url('<?php echo base_url();?>/assets/images/background.jpg');" data-aos="fade" data-stellar-background-ratio="0.5" id="section-home">
      <div class="container">
        <div class="row align-items-center justify-content-center text-center">

          <div class="col-md-8" data-aos="fade-up" data-aos-delay="400">
            

            <h1 class="text-white font-weight-light text-uppercase font-weight-bold" data-aos="fade-up">PT. Care Indonesia Solusi</h1>
            <p class="mb-5" data-aos="fade-up" data-aos-delay="100">We Are Work in Consulting HRD And Recruiter</p>
            <p data-aos="fade-up" data-aos-delay="200"><a href="#" class="btn btn-success py-3 px-5 text-white">Get Started!</a></p>

          </div>
        </div>
      </div>
    </div>  

    <div class="site-section" id="section-about">
      <div class="container">
        <div class="row mb-5">
          
          <div class="col-md-5 ml-auto mb-5 order-md-2" data-aos="fade-up" data-aos-delay="100">
            <img src="<?php echo base_url();?>assets/images/Admin.jpg" alt="Image" class="img-fluid rounded">
          </div>
          <div class="col-md-6 order-md-1" data-aos="fade-up">
            <div class="text-left pb-1 border-primary mb-4">
              <h2 class="text-primary">About Us</h2>
            </div>
            
              <p>Welcome to PT Care Indonesia Solusi</p>
              <p class="mb-4">PT Care Indonesia Solusi is the best place to get training and articles about the development of human resources, careers, self development and job vacancies. Here Careers can find lots of information, articles, tips and advice about careers, self-development, skills, human resource management, job openings and other useful things.</p>

              <p class="mb-4">In addition, you can find all information about the training we hold and job openings</p>
            
          </div>
          
        </div>
      </div>
    </div>
  
    <div class="site-section bg-image overlay" style="background-image: url('<?php echo base_url();?>/assets/images/Admin.jpg');" id="section-how-it-works">
      <div class="container">
        <div class="row justify-content-center mb-5">
          <div class="col-md-7 text-center border-primary">
            <h2 class="font-weight-light text-primary" data-aos="fade">How It Works</h2>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6 col-lg-4 mb-5 mb-lg-0" data-aos="fade" data-aos-delay="100">
            <div class="how-it-work-item">
              <span class="number">1</span>
              <div class="how-it-work-body">
                <h2>Make An Order</h2>
                <p class="mb-5">Lorem ipsum dolor sit amet consectetur adipisicing elit. Incidunt praesentium dicta consectetur fuga neque fugit a at. Cum quod vero assumenda iusto.</p>
                <ul class="ul-check list-unstyled success">
                  <li class="text-white">Error minus sint nobis dolor</li>
                  <li class="text-white">Voluptatum porro expedita labore esse</li>
                  <li class="text-white">Voluptas unde sit pariatur earum</li>
                </ul>
              </div>
            </div>
          </div>

          <div class="col-md-6 col-lg-4 mb-5 mb-lg-0" data-aos="fade" data-aos-delay="200">
            <div class="how-it-work-item">
              <span class="number">2</span>
              <div class="how-it-work-body">
                <h2>Make A Payment</h2>
                <p class="mb-5">Lorem ipsum dolor sit amet consectetur adipisicing elit. Incidunt praesentium dicta consectetur fuga neque fugit a at. Cum quod vero assumenda iusto.</p>
                <ul class="ul-check list-unstyled success">
                  <li class="text-white">Error minus sint nobis dolor</li>
                  <li class="text-white">Voluptatum porro expedita labore esse</li>
                  <li class="text-white">Voluptas unde sit pariatur earum</li>
                </ul>
              </div>
            </div>
          </div>

          <div class="col-md-6 col-lg-4 mb-5 mb-lg-0" data-aos="fade" data-aos-delay="300">
            <div class="how-it-work-item">
              <span class="number">3</span>
              <div class="how-it-work-body">
                <h2>Track Your Order</h2>
                <p class="mb-5">Lorem ipsum dolor sit amet consectetur adipisicing elit. Incidunt praesentium dicta consectetur fuga neque fugit a at. Cum quod vero assumenda iusto.</p>
                <ul class="ul-check list-unstyled success">
                  <li class="text-white">Error minus sint nobis dolor</li>
                  <li class="text-white">Voluptatum porro expedita labore esse</li>
                  <li class="text-white">Voluptas unde sit pariatur earum</li>
                </ul>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>

    <div class="site-section border-bottom" id="section-our-team">
      <div class="container">
        <div class="row justify-content-center mb-5">
          <div class="col-md-7 text-center border-primary">
            <h2 class="font-weight-light text-primary" data-aos="fade">Our Partner</h2>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6 col-lg-4 mb-5 mb-lg-0" data-aos="fade" data-aos-delay="100">
            <div class="person">
              <img src="<?php echo base_url();?>assets/images/bina_karirlogo.png" alt="Image" class="img-fluid rounded mb-5 w-75">
              <h3>Binakarir</h3>
              <p class="position text-muted">Binakarir</p>
              <p class="mb-4">Lorem ipsum dolor sit amet consectetur adipisicing elit. Nisi at consequatur unde molestiae quidem provident voluptatum deleniti quo iste error eos est praesentium distinctio cupiditate tempore suscipit inventore deserunt tenetur.</p>
              <ul class="ul-social-circle">
                <li><a href="#"><span class="icon-facebook"></span></a></li>
                <li><a href="#"><span class="icon-twitter"></span></a></li>
                <li><a href="#"><span class="icon-linkedin"></span></a></li>
                <li><a href="#"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 mb-5 mb-lg-0" data-aos="fade" data-aos-delay="200">
            <div class="person">
              <img src="<?php echo base_url();?>assets/images/logo_hrindo.png" alt="Image" class="img-fluid rounded mb-5 w-75">
              <h3>HR Indo</h3>
              <p class="position text-muted">HR Indo</p>
              <p class="mb-4">Lorem ipsum dolor sit amet consectetur adipisicing elit. Nisi at consequatur unde molestiae quidem provident voluptatum deleniti quo iste error eos est praesentium distinctio cupiditate tempore suscipit inventore deserunt tenetur.</p>
              <ul class="ul-social-circle">
                <li><a href="#"><span class="icon-facebook"></span></a></li>
                <li><a href="#"><span class="icon-twitter"></span></a></li>
                <li><a href="#"><span class="icon-linkedin"></span></a></li>
                <li><a href="#"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 mb-5 mb-lg-0" data-aos="fade" data-aos-delay="300">
            <div class="person">
              <img src="<?php echo base_url();?>assets/images/logo_binadata.png" alt="Image" class="img-fluid rounded mb-5 w-75">
              <h3>BinaData Analytics</h3>
              <p class="position text-muted">BinaData Analystics</p>
              <p class="mb-4">Lorem ipsum dolor sit amet consectetur adipisicing elit. Nisi at consequatur unde molestiae quidem provident voluptatum deleniti quo iste error eos est praesentium distinctio cupiditate tempore suscipit inventore deserunt tenetur.</p>
              <ul class="ul-social-circle">
                <li><a href="#"><span class="icon-facebook"></span></a></li>
                <li><a href="#"><span class="icon-twitter"></span></a></li>
                <li><a href="#"><span class="icon-linkedin"></span></a></li>
                <li><a href="#"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="site-section bg-light" id="section-services">
      <div class="container">
        <div class="row justify-content-center mb-5" data-aos="fade-up">
          <div class="col-md-7 text-center border-primary">
            <h2 class="mb-0 text-primary">Our Services</h2>
            <p class="color-black-opacity-5"></p>
          </div>
        </div>
        <div class="row align-items-stretch">
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4" data-aos="fade-up">
            <div class="unit-4 d-flex">
              <div class="unit-4-icon mr-4"><span class="text-primary flaticon-work"></span></div>
              <div>
                <h3>Training</h3>
                <p>PT Care Indonesia is the best place to conduct training, because you can find a lot of information in human resources.</p>
                <p><a href="#">Learn More</a></p>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4" data-aos="fade-up" data-aos-delay="100">
            <div class="unit-4 d-flex">
              <div class="unit-4-icon mr-4"><span class="text-primary flaticon-web"></span></div>
              <div>
                <h3>Web Development</h3>
                <p>PT Care Indonesia Solusi is a Corporate Web Designer & Web Developer that provides professional website creation services for companies with optional packages: BASIC, BUSINESS & CUSTOM Packages.</p>
                <p><a href="#">Learn More</a></p>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-4 mb-4 mb-lg-4" data-aos="fade-up" data-aos-delay="200">
            <div class="unit-4 d-flex">
              <div class="unit-4-icon mr-4"><span class="text-primary flaticon-android"></span></div>
              <div>
                <h3>Aplication Development</h3>
                <p>PT Care Indonesia Solusi is a Corporate Application for Android and IOS Developers that provides professional website creation services for companies with optional packages: BASIC, BUSINESS & CUSTOM Packages.</p>
                <p><a href="#">Learn More</a></p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>

  

    <div class="site-section bg-light" id="section-contact">
      <div class="container">
        <div class="row justify-content-center mb-5">
          <div class="col-md-7 text-center border-primary">
            <h2 class="font-weight-light text-primary">Contact Us</h2>
            <p class="color-black-opacity-5">See Our Daily News &amp; Updates</p>
          </div>
        </div>
        <div class="row">
          <div class="col-md-7 mb-5">
            <form action="#" class="p-5 bg-white">
             
              <div class="row form-group">
                <div class="col-md-6 mb-3 mb-md-0">
                  <label class="text-black" for="fname">First Name</label>
                  <input type="text" id="fname" class="form-control">
                </div>
                <div class="col-md-6">
                  <label class="text-black" for="lname">Last Name</label>
                  <input type="text" id="lname" class="form-control">
                </div>
              </div>

              <div class="row form-group">
                
                <div class="col-md-12">
                  <label class="text-black" for="email">Email</label> 
                  <input type="email" id="email" class="form-control">
                </div>
              </div>

              <div class="row form-group">
                
                <div class="col-md-12">
                  <label class="text-black" for="subject">Subject</label> 
                  <input type="subject" id="subject" class="form-control">
                </div>
              </div>

              <div class="row form-group">
                <div class="col-md-12">
                  <label class="text-black" for="message">Message</label> 
                  <textarea name="message" id="message" cols="30" rows="7" class="form-control"></textarea>
                </div>
              </div>

              <div class="row form-group">
                <div class="col-md-12">
                  <input type="submit" value="Send Message" class="btn btn-primary py-2 px-4 text-white">
                </div>
              </div>

  
            </form>
          </div>
          <div class="col-md-5">
            
            <div class="p-4 mb-3 bg-white">
              <p class="mb-0 font-weight-bold">Address</p>
              <p class="mb-4">Ruko Surapati Core Blok. C No. 22, Jalan PH.H. Hasan Mustofa, Pasirlayung, Cibeunying Kidul, Pasirlayung, Cibeunying Kidul, Kota Bandung, Jawa Barat 40192</p>

              <p class="mb-0 font-weight-bold">Phone</p>
              <p class="mb-4"><a href="#">+62 857-9577-3738</a></p>

              <p class="mb-0 font-weight-bold">Email Address</p>
              <p class="mb-0"><a href="#">cvbinakarir@gmail.com</a></p>

            </div>
            
            <div class="p-4 mb-3 bg-white">
              <h3 class="h5 text-black mb-3">More Info</h3>
              <p>Welcome to the PT Care Indonesia Solusi</p>
              <p>PT Care Indonesia Solusi is the best place to get training and articles about the development of human resources, careers, self development and job vacancies. Here Careers can find lots of information, articles, tips and advice about careers, self-development, skills, human resource management, job openings and other useful things.</p>
            </div>

          </div>
        </div>
      </div>
    </div>
  
    
    <footer class="site-footer">
      <div class="container">
        <div class="text-center">
          <div class="col-md-12">
              <small class="block">&copy; <script>document.write(new Date().getFullYear());</script> Design Web Developer. All Rights Reserved. <br> Designed &amp; Developed by <a href="#">PT Care Indonesia Solusi</a></small>
          </div>
          
        </div>
      </div>
    </footer>
  <!-- </div> -->

  <script src="<?php echo base_url();?>/assets/js/jquery-3.3.1.min.js"></script>
  <script src="<?php echo base_url();?>/assets/js/jquery-migrate-3.0.1.min.js"></script>
  <script src="<?php echo base_url();?>/assets/js/jquery-ui.js"></script>
  <script src="<?php echo base_url();?>/assets/js/jquery.easing.1.3.js"></script>
  <script src="<?php echo base_url();?>/assets/js/popper.min.js"></script>
  <script src="<?php echo base_url();?>/assets/js/bootstrap.min.js"></script>
  <script src="<?php echo base_url();?>/assets/js/owl.carousel.min.js"></script>
  <script src="<?php echo base_url();?>/assets/js/jquery.stellar.min.js"></script>
  <script src="<?php echo base_url();?>/assets/js/jquery.countdown.min.js"></script>
  <script src="<?php echo base_url();?>/assets/js/jquery.magnific-popup.min.js"></script>
  <script src="<?php echo base_url();?>/assets/js/bootstrap-datepicker.min.js"></script>
  <script src="<?php echo base_url();?>/assets/js/aos.js"></script>

  <script src="<?php echo base_url();?>/assets/js/main.js"></script>
    
  </body>
</html>